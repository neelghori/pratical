import { ErrorRequestHandler, NextFunction, Request, Response } from "express";
import { ProductModals } from "../models/product";
import {
  CartProductComboProps,
  CreateProductControllerReqbody,
  ResponseHandler,
} from "../Types/Common";

export const createProductController = async (
  req: Request<
    any,
    any,
    CreateProductControllerReqbody,
    any,
    Record<string, any>
  >,
  res: Response,
  next: NextFunction
) => {
  try {
    const reqBody = req.body;
    const data: any = await ProductModals.createProduct({ ...reqBody });
    if (data?.error) {
      //@ts-ignore
      return res.errorHandler({
        res,
        message: data?.message,
        statusCode: 200,
        status: false,
      });
    }
    //@ts-ignore
    res.handler({
      res,
      statusCode: 200,
      status: true,
      message: "Products Create Successfully",
    });
  } catch (error) {
    console.log("create product err: ", error);
    //@ts-ignore
    res.errorHandler({ res });
  }
};

export const UpdateProductController = async (
  req: Request<
    any,
    any,
    CreateProductControllerReqbody,
    any,
    Record<string, any>
  >,
  res: Response,
  next: NextFunction
) => {
  try {
    const reqBody = req.body;
    const { id } = req.params;
    const data = await ProductModals.EditProduct(id, reqBody);
    //@ts-ignore
    res.handler({
      res,
      data,
      statusCode: 200,
      status: true,
      message: "Product Update Successfully",
    });
  } catch (error) {
    console.log("edit product err: ", error);
    //@ts-ignore
    res.errorHandler({ res });
  }
};

export const DeleteProductController = async (
  req: Request<{ id: string }, any, any, any, Record<string, any>>,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;
    const data: any = await ProductModals.deleteProduct(id);
    if (data?.error) {
      //@ts-ignore
      return res.errorHandler({
        res,
        message: data?.message,
        statusCode: 200,
        status: false,
      });
    }
    //@ts-ignore
    res.handler({
      res,
      statusCode: 200,
      status: true,
      message: "Product Delete Successfully",
    });
  } catch (error) {
    console.log("delete product err: ", error);
    //@ts-ignore
    res.errorHandler({ res });
  }
};

export const ListProductController = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const data = await ProductModals.listProduct();
    //@ts-ignore
    res.handler({ res, message: "Product fetch successfully", data });
  } catch (err) {
    console.log(" listProduct err: ", err);
    //@ts-ignore
    res.errorHandler({ res });
  }
};

export const CheckComboPrice = async (
  req: Request<any, any, CartProductComboProps[], any>,
  res: Response,
  next: NextFunction
) => {
  try {
    const reqBody = req.body;
    let discountedTotal;
    if (reqBody.length > 1) {
      let discount = 2; // 10% discount for example
      let total = reqBody.reduce(
        (sum, product) =>
          sum +
          (product.product_discount
            ? parseInt(product.product_discount)
            : parseInt(product.product_price)),
        0
      );
      discountedTotal = total - (total * discount) / 100;
    }
    const ExtractID = reqBody.map((ele) => ele._id);
    const data = await ProductModals.checkCombo(ExtractID);
    //@ts-ignore
    res.handler({
      res,
      message: "Product fetch successfully",
      data: {
        product: data,
        discountTotal: discountedTotal,
      },
    });
  } catch (err) {
    console.log(" listProduct err: ", err);
    //@ts-ignore
    res.errorHandler({ res });
  }
};
