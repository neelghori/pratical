import { CreateProductBody } from "../Types/Common";
import { ProductSchemaModal } from "../database/Schema/ProductSchema";

class ProductModal {
  async createProduct(data: CreateProductBody) {
    const result = await ProductSchemaModal.create(data);
    if (!result) {
      return {
        error: true,
        message: "Product Create Failed",
      };
    }
    return {
      ...result,
    };
  }
  async EditProduct(productId: string, data: any) {
    const isExist = await ProductSchemaModal.findOne({
      _id: productId,
    });
    if (!isExist) {
      return {
        error: true,
        message: "Invalid Product id",
      };
    }
    const result = await ProductSchemaModal.updateOne(
      {
        _id: productId,
      },
      {
        $set: {
          product_title: data.product_title,
          product_price: data.product_price,
          product_discount: data.product_discount,
          offer_price: data.offer_price,
          image: data.image,
        },
      }
    );
    if (!result) {
      return {
        error: true,
        message: "Product Update Failed",
      };
    }
    return {
      ...result,
    };
  }

  async deleteProduct(task_id: string) {
    const isExist = await ProductSchemaModal.findOne({
      _id: task_id,
    });
    if (!isExist) {
      return {
        error: true,
        message: "Invalid Product id",
      };
    }
    return await ProductSchemaModal.deleteOne({ _id: task_id });
  }
  async listProduct() {
    const result = await ProductSchemaModal.find().sort({ _id: -1 });
    return result;
  }

  async checkCombo(reqBody: string[]) {
    const result = await ProductSchemaModal.find({
      _id: {
        $in: reqBody,
      },
    });
    return result;
  }
}

export const ProductModals = new ProductModal();
