import { Response } from "express";

export interface ResponseHandler<T> {
  res: Response;
  message: string;
  data: T;
  statusCode: number;
  status: number;
  errors: string;
}

export interface CustomResponse extends Response {
  handler: any;
  errorHandler: any;
}

export interface CreateProductBody {
  product_title: string;
  product_price: string;
  product_discount: string;
  offer_price: string;
  image?: string;
}

export interface CreateProductControllerReqbody extends CreateProductBody {}

export interface CartProductComboProps extends CreateProductBody {
  _id: string;
}
