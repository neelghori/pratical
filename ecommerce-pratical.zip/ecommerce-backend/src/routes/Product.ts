import express, { Router } from "express";
import { uploadFile } from "../utils/helper";
import {
  CheckComboPrice,
  DeleteProductController,
  ListProductController,
  UpdateProductController,
  createProductController,
} from "../controller/productController";

export const productRoutes: Router = express.Router();

//product create routes
productRoutes.post("/product/create", (req, res, next) => {
  createProductController(req, res, next);
});

//product update routes
productRoutes.put("/product/update/:id", (req, res, next) =>
  UpdateProductController(req, res, next)
);

//product delete routes
productRoutes.delete("/product/delete/:id", (req, res, next) =>
  DeleteProductController(req, res, next)
);

//product list routes
productRoutes.get("/product/", (req, res, next) =>
  ListProductController(req, res, next)
);
productRoutes.post("/product/checkComboPrice", (req, res, next) =>
  CheckComboPrice(req, res, next)
);
