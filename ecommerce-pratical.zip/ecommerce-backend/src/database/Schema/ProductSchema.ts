import mongoose from "mongoose";
import moment from "moment";
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
  product_title: {
    type: String,
    required: true,
  },
  product_price: {
    type: String,
    required: true,
  },
  product_discount: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  image: {
    type: String,
    required: false,
  },
  created_at: {
    type: String,
    default: moment().format("MMM DD YYYY HH:mm:ss"),
  },
  updated_at: {
    type: String,
    default: moment().format("MMM DD YYYY HH:mm:ss"),
  },
});

export const ProductSchemaModal = mongoose.model("Products", ProductSchema);
