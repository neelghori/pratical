import express, { NextFunction, Request, Response } from "express";
import dotenv from "dotenv";
import bodyparser from "body-parser";
import cors from "cors";
import { databaseConnection } from "./database/connection";
import { responseHandler } from "./utils/handler/reponseHandler";
import { ErrorHandler } from "./utils/handler/ErrorHandler";
import { productRoutes } from "./routes/Product";
import path from "path";
dotenv.config();

const app = express();
const port = process.env.PORT || 3003;
const photosPath = path.join(__dirname, "photos");

app.use("/images", express.static(photosPath));

// ------------------------- DATABSE CONNECTION  ------------------------------
databaseConnection();

// ------------------------ GLOBAL MIDDLE WARES -------------------------
app.use(bodyparser.json());
app.use(cors());

// ------------------------    RESPONSE HANDLER    -------------------
app.use((req: Request, res: Response, next: NextFunction) => {
  //@ts-ignore
  res.handler = responseHandler;
  next();
});

// ------------------------    Error HANDLER    -------------------
app.use((req: Request, res: Response, next: NextFunction) => {
  //@ts-ignore
  res.errorHandler = ErrorHandler;
  next();
});

// -------------------------- ROUTES ----------------------
app.use("/", productRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

export default app;
