/* eslint-disable react/prop-types */
import { ShoppingBagIcon } from "@heroicons/react/16/solid";
import Button from "../UI/Button";
import { useContext } from "react";
import { GlobalStateProvider } from "../../Context/GlobalState";
import AddProduct from "../Product/AddProduct";

const Header = (props) => {
  const { state, dispatch } = useContext(GlobalStateProvider);
  return (
    <>    <div className="flex fixed  w-full bg-white shadow-lg z-40 h-32">
      <div className="flex gap-10 justify-between w-full mx-auto max-w-7xl items-center">
        <h1 className="text-4xl font-bold text-gray-900">Product List</h1>
        <div className="flex gap-10 items-center">
          <ShoppingBagIcon className="size-8 cursor-pointer" onClick={() => dispatch({ type: "checkoutModal", payload: true })} />
          <Button onClick={() => {
            dispatch({ type: "OpenProductFormModal", payload: !state.productFormModal })
          }}>Add Product</Button>
        </div>
      </div>
    </div>
      <AddProduct setProduct={props?.setProduct} />
    </>

  );
};

export default Header;
