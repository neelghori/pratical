/* eslint-disable react/prop-types */
import Button from '../UI/Button'
import Input from '../UI/Input'
import { useFormik } from 'formik'
import * as Yup from "yup"
import { useContext } from 'react'
import { GlobalStateProvider } from '../../Context/GlobalState'
import Dialog from '../UI/Dialog'
import { addProductApi, getProductListApi } from '../../lib/addProductApi'
import { toast } from 'sonner'
const AddProduct = (props) => {
    const { state, dispatch } = useContext(GlobalStateProvider);
    const openClose = () => {
        dispatch({ type: "OpenProductFormModal", payload: !state.productFormModal })

    }
    const formik = useFormik({
        initialValues: {
            product_title: "",
            product_price: 0,
            product_discount: 0,
            description: "",
        },
        validationSchema: Yup.object().shape({
            product_title: Yup.string()
                .trim()
                .required("Please Enter  Product Name"),
            product_price: Yup.string()
                .trim()
                .min(0)
                .required("Please Enter  Product Price"),
            product_discount: Yup.string()
                .trim()
                .optional()
                .required("Please Enter  Discount"),
            description: Yup.string()
                .trim()
                .required("Please Enter Product Description"),
        }),
        onSubmit: async (values, { resetForm }) => {
            const response = await addProductApi(values);
            if (response.status) {
                const response = await getProductListApi();
                if (response.status) {
                    props?.setProduct(response.data)
                }
                toast.success(response.message)
                openClose();
                resetForm();
            } else {
                toast.error(response.message)
            }

        }
    })
    const { handleBlur, handleChange, handleSubmit, values, errors, touched, isSubmitting } = formik;

    return (
        <Dialog open={state?.productFormModal} title={"Add Product"} onCloseModal={openClose}>
            <div>
                <form onSubmit={handleSubmit}>
                    <div>
                        <div className='grid grid-cols-2 gap-3'>
                            <Input onChange={handleChange} label={"Product Name"} onBlur={handleBlur} touched={touched?.product_title} errors={errors?.product_title} value={values.product_title} type="text" id="product_title" placeholder="Enter Product Name" />
                            <Input onChange={handleChange} label={"Product Price"} onBlur={handleBlur} touched={touched?.product_price} errors={errors?.product_price} value={values.product_price} type="number" id="product_price" placeholder="Enter Product Price" />
                            <Input onChange={handleChange} label={"Product Discount Price"} onBlur={handleBlur} touched={touched?.product_discount} errors={errors?.product_discount} value={values.product_discount} type="number" id="product_discount" placeholder="Enter Discount Price" />
                            <Input onChange={handleChange} label={"Product Description"} onBlur={handleBlur} touched={touched?.description} errors={errors?.description} value={values.description} type="text" id="description" placeholder="Enter Description" />
                        </div>
                        <div className='flex justify-end items-end mr-5 mt-5'>
                            <Button disabled={isSubmitting}>{isSubmitting ? "Adding..." : "Add Product"}</Button>
                        </div>
                    </div>
                </form>
            </div>
        </Dialog>
    )
}

export default AddProduct