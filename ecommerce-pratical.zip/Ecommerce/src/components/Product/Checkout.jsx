import { useContext, useEffect } from "react";
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import Button from "../UI/Button";
import { GlobalStateProvider } from "../../Context/GlobalState";
import { getComboOfferApi } from "../../lib/addProductApi";

export default function CheckoutPage() {
  const { state, dispatch } = useContext(GlobalStateProvider);
  const getComboOffer = async (reqbody) => {
    const response = await getComboOfferApi(reqbody);
    if (response.status) {
      dispatch({ type: "ApplyComboOffer", payload: response.data })
    }
  }
  useEffect(() => {
    if (state?.cart && state?.cart.length > 0) {
      getComboOffer(state?.cart);
    }
  }, [state?.cart])
  const CheckoutTotal = state?.cart && state?.cart.length > 0 ? state?.cart.reduce((acc, curr) => acc + (curr.product_discount ? parseInt(curr.product_discount) : parseInt(curr.product_price)), 0) : 0
  return (
    <Transition show={state?.checkoutModal}>
      <Dialog
        className="relative z-50"
        onClose={() =>
          dispatch({ type: "checkoutModal", payload: !state?.checkoutModal })
        }
      >
        <TransitionChild
          enter="ease-in-out duration-500"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in-out duration-500"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </TransitionChild>

        <div className="fixed inset-0 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <TransitionChild
                enter="transform transition ease-in-out duration-500 sm:duration-700"
                enterFrom="translate-x-full"
                enterTo="translate-x-0"
                leave="transform transition ease-in-out duration-500 sm:duration-700"
                leaveFrom="translate-x-0"
                leaveTo="translate-x-full"
              >
                <DialogPanel className="pointer-events-auto w-screen max-w-md">
                  <div className="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
                    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
                      <div className="flex items-start justify-between">
                        <DialogTitle className="text-lg font-medium text-gray-900">
                          Shopping cart
                        </DialogTitle>
                        <div className="ml-3 flex h-7 items-center">
                          <button
                            type="button"
                            className="relative -m-2 p-2 text-gray-400 hover:text-gray-500"
                            onClick={() =>
                              dispatch({
                                type: "checkoutModal",
                                payload: false,
                              })
                            }
                          >
                            <span className="absolute -inset-0.5" />
                            <span className="sr-only">Close panel</span>
                            <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                          </button>
                        </div>
                      </div>

                      <div className="mt-8">
                        <div className="flow-root">
                          <ul
                            role="list"
                            className="-my-6 divide-y divide-gray-200"
                          >
                            {state?.cart && state?.cart.length > 0 && state.cart.map((product) => (
                              <li key={product._id} className="flex py-6">
                                <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                                  <img
                                    src={"https://tailwindui.com/img/ecommerce-images/product-page-03-related-product-01.jpg"}
                                    alt={"image"}
                                    className="h-full w-full object-cover object-center"
                                  />
                                </div>

                                <div className="ml-4 flex flex-1 flex-col">
                                  <div>
                                    <div className="flex justify-between text-base font-medium text-gray-900">
                                      <h3>
                                        <a href={product.href}>
                                          {product.product_title}
                                        </a>
                                      </h3>
                                      <p className="ml-4">{product.product_discount ? <span className="text-lg">${product.product_discount}<span className={`pl-3 text-sm`}><del>${product.product_price}</del></span></span> : <span>${product.product_price}</span>}
                                      </p>
                                    </div>
                                    <p className="mt-1 text-sm text-gray-500">
                                      {product.description}
                                    </p>
                                  </div>
                                  <div className="flex flex-1 items-end justify-between text-sm">
                                    <p className="text-gray-500">
                                      Qty {product.quantity}
                                    </p>

                                    <div className="flex">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          dispatch({ type: "RemoveProductFromCart", payload: { id: product._id } })
                                        }}
                                        className="font-medium text-indigo-600 hover:text-indigo-500"
                                      >
                                        Remove
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 px-4 py-6 sm:px-6">
                      {
                        state.comboOffer ? <div className="flex justify-end text-sm text-indigo-500">
                          Saved  2%
                        </div> : null
                      }
                      <div className="flex justify-between text-base font-medium text-gray-900">
                        <p>Subtotal</p>
                        <p className="ml-4">{state.comboOffer ? <span className="text-lg">${state.comboOffer}<span className={`pl-3 text-sm`}><del>${CheckoutTotal}</del></span></span> : <span>${CheckoutTotal}</span>}</p>
                      </div>
                      <div className="mt-6">
                        <Button classnames="w-full">Checkout</Button>
                      </div>
                    </div>
                  </div>
                </DialogPanel>
              </TransitionChild>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
