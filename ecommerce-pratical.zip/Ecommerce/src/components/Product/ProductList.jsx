import { useContext, useEffect, useState } from "react";
import Header from "../Layout/Header";
import { getProductListApi } from "../../lib/addProductApi";
import { GlobalStateProvider } from "../../Context/GlobalState";


export default function ProductList() {
  const { dispatch } = useContext(GlobalStateProvider)
  const [products, setProduct] = useState([]);
  useEffect(() => {
    getProductList();
  }, [])
  const getProductList = async () => {
    const response = await getProductListApi();
    if (response.status) {
      setProduct(response.data)
    } else {
      setProduct([])
    }
  }
  return (
    <>
      <Header setProduct={setProduct} />
      <div className="bg-white">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-8">
          <div className="relative top-36 py-10 grid grid-cols-1 gap-y-12 sm:grid-cols-2 sm:gap-x-6 lg:grid-cols-4 xl:gap-x-8">
            {products && products.length > 0 && products.map((product) => (
              <div key={product._id}>
                <div className="relative">
                  <div className="relative h-72 w-full overflow-hidden rounded-lg">
                    <img
                      src={"https://tailwindui.com/img/ecommerce-images/product-page-03-related-product-01.jpg"}
                      alt={"image"}
                      className="h-full w-full object-cover object-center"
                    />
                  </div>
                  <div className="relative mt-4">
                    <h3 className="text-sm font-medium text-gray-900">
                      {product.product_title}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {product.description}
                    </p>
                    <p className="mt-1 text-sm text-gray-500">
                      {product.product_discount ? <span className="text-lg">${product.product_discount}<span className={`pl-3 text-sm`}><del>${product.product_price}</del></span></span> : <span>${product.product_price}</span>}
                    </p>
                  </div>
                </div>
                <div className="mt-6">
                  <button
                    onClick={() => {
                      dispatch({ type: "AddToCart", payload: product })
                    }}
                    className="relative w-full flex cursor-pointer items-center justify-center rounded-md border border-transparent bg-gray-100 px-8 py-2 text-sm font-medium text-gray-900 hover:bg-gray-200"
                  >
                    Add to bag
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
