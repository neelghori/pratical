import './App.css'
import CheckoutPage from './components/Product/Checkout'
import ProductList from './components/Product/ProductList'

function App() {

  return (
    <>
      <ProductList />
      <CheckoutPage />
    </>
  )
}

export default App
