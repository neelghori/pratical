import React, { useReducer } from "react";
import { ReducerFunction, initialValue } from "./ReducerFunction";

export const GlobalStateProvider = React.createContext({
  state: initialValue,
  dispatch: () => { },
});

// eslint-disable-next-line react/prop-types
const GlobalState = ({ children }) => {
  const [state, dispatch] = useReducer(ReducerFunction, initialValue);
  return (
    <GlobalStateProvider.Provider value={{ state, dispatch }}>
      {children}
    </GlobalStateProvider.Provider>
  );
};

export default GlobalState;
