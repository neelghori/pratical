import { toast } from "sonner";

/* eslint-disable no-case-declarations */
export const initialValue = {
  cart: [],
  checkoutModal: false,
  productFormModal: false,
  comboOffer: 0
};

export const ReducerFunction = (state, action) => {
  switch (action.type) {
    case "checkoutModal":
      state = {
        ...state,
        checkoutModal: action.payload,
      };
      return state;
    case "AddToCart":
      let duplicate = state.cart && state.cart.length > 0 ? [...state.cart] : [];
      duplicate.push({ ...action.payload, quantity: 1 })
      state = {
        ...state,
        cart: duplicate,
      };
      toast.success("Product Add to Cart")
      return state;
    case "RemoveProductFromCart":
      let StateCart = [...state.cart];
      state = {
        ...state,
        cart: StateCart.filter((ele) => ele._id !== action?.payload?.id),
      };
      return state;
    case "OpenProductFormModal":
      state = {
        ...state,
        productFormModal: action?.payload
      };
      return state;
    case "ApplyComboOffer":
      state = {
        ...state,
        comboOffer: action.payload.discountTotal
      }
      return state
    default:
      return state;
  }
};
