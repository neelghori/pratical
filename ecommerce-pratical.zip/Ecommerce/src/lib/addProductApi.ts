import ApiCall from "./Api";

export const addProductApi = async (body) => {
  const response = await ApiCall("/product/create", "POST", body);
  return response;
};

export const getProductListApi = async () => {
  const response = await ApiCall("/product", "GET");
  return response;
};

export const getComboOfferApi = async (body) => {
  const response = await ApiCall("/product/checkComboPrice", "POST", body);
  return response;
};
